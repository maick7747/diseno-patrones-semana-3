/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package reporte;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServicioReportes servicio = new ServicioReportes();

        // Lista
        GeneradorReporte[] generadores = {
            new GeneradorPDF(),
            new GeneradorExcel(),
            new GeneradorCSV(),
            new GeneradorHTML()
        };

        System.out.println("--- Ejecutando el Servicio de Reportes Separado por Archivos ---");
        for (GeneradorReporte g : generadores) {
            servicio.ejecutar(g);
        }
    }
}
