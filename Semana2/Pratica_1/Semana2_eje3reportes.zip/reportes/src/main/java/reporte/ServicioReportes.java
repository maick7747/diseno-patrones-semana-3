/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package reporte;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class ServicioReportes {

    public void ejecutar(GeneradorReporte generador) {

        generador.generar();
    }
}
