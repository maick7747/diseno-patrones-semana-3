/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reportes;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class Reportes {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
