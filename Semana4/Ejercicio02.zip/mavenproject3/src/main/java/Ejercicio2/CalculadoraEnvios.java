/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio2;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class CalculadoraEnvios {

    private EstrategiaEnvio estrategia;

    public void setEstrategia(EstrategiaEnvio estrategia) {
        this.estrategia = estrategia;
    }

    public double calcularTarifa(double peso, double distancia) {
        if (estrategia == null) {
            System.out.println("Error: No se ha seleccionado una estrategia de envío.");
            return 0.0;
        }
        return estrategia.calcularTarifa(peso, distancia);
    }
}
