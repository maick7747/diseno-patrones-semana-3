/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio2;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class EnvioMaritimoInternacional implements EstrategiaEnvio {

    @Override
    public double calcularTarifa(double peso, double distancia) {
        return (peso * 0.9) + 150.0;
    }
}
