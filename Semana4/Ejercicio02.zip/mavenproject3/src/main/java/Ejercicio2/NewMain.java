/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio2;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        double peso = 12.5;       // en kg
        double distancia = 250.0; // en km

        CalculadoraEnvios calculadora = new CalculadoraEnvios();

        System.out.println("Datos del envío -> Peso: " + peso + " kg | Distancia: " + distancia + " km\n");

        calculadora.setEstrategia(new EnvioExpressAereo());
        double tarifaAerea = calculadora.calcularTarifa(peso, distancia);
        System.out.println("[Express_Aereo] Tarifa calculada: $" + tarifaAerea);

        calculadora.setEstrategia(new EnvioTerrestreNormal());
        double tarifaTerestre = calculadora.calcularTarifa(peso, distancia);
        System.out.println("[Terrestre_Normal] Tarifa calculada: $" + tarifaTerestre);

        calculadora.setEstrategia(new EnvioMaritimoInternacional());
        double tarifaMaritima = calculadora.calcularTarifa(peso, distancia);
        System.out.println("[Maritimo_Internacional] Tarifa calculada: $" + tarifaMaritima);
    }
}
