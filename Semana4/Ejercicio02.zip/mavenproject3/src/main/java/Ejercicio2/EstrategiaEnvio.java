/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Ejercicio2;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public interface EstrategiaEnvio {

    double calcularTarifa(double peso, double distancia);
}
