/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio04;

/**
 *
 * @author huatu
 */
public class ModuloInventario {
    private ConfiguradorGlobal config;

    public ModuloInventario() {
        // Obtiene la misma instancia compartida
        this.config = ConfiguradorGlobal.getInstance();
        System.out.println("Modulo de Inventario creado.");
    }

    public void ejecutar() {
        System.out.println("Inventario usando config: " + config.getConfig("STOCK_MINIMO"));
    }
}