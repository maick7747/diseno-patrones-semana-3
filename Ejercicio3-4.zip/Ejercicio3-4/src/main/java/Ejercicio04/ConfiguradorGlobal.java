/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio04;

/**
 *
 * @author huatu
 */
public class ConfiguradorGlobal {
    private static volatile ConfiguradorGlobal instanciaUnica;

    private ConfiguradorGlobal() {
        System.out.println("Leyendo variables de entorno y conectando al servidor de config...");
        
        try {
            Thread.sleep(2000); 
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Configurador inicializado correctamente (única instancia).");
    }

    public static ConfiguradorGlobal getInstance() {
        if (instanciaUnica == null) {
            synchronized (ConfiguradorGlobal.class) {
                if (instanciaUnica == null) {
                    instanciaUnica = new ConfiguradorGlobal();
                }
            }
        }
        return instanciaUnica;
    }

    public String getConfig(String clave) {
        return "Valor_Configurado_Para_" + clave;
    }
}