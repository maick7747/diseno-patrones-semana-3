/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio04;

/**
 *
 * @author huatu
 */
public class MainSingleton {
    public static void main(String[] args) {
        System.out.println("=== Iniciando Sistema ===");
        
        ModuloVentas ventas = new ModuloVentas();
        ModuloInventario inventario = new ModuloInventario();

        ventas.ejecutar();
        inventario.ejecutar();

        System.out.println("Ambos modulos comparten la misma instancia? " 
            + (ConfiguradorGlobal.getInstance() == ConfiguradorGlobal.getInstance()));
    }
}