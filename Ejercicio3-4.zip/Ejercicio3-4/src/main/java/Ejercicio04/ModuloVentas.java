/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio04;

/**
 *
 * @author huatu
 */
public class ModuloVentas {
    private ConfiguradorGlobal config;

    public ModuloVentas() {
        // Obtiene la misma instancia compartida
        this.config = ConfiguradorGlobal.getInstance();
        System.out.println("Modulo de Ventas creado.");
    }

    public void ejecutar() {
        System.out.println("Ventas usando config: " + config.getConfig("IMPUESTO"));
    }
}
