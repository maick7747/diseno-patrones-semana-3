/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio03;

/**
 *
 * @author huatu
 */
public class PantallaLobby implements ObservadorClima {
    @Override
    public void actualizar(float temperatura) {
        renderizarTemperatura(temperatura);
    }

    public void renderizarTemperatura(float temp) {
        System.out.println("Pantalla Lobby renderiza: " + temp + "C");
    }
}