/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio03;

/**
 *
 * @author huatu
 */
public class MainClima {
    public static void main(String[] args) {
        EstacionMeteorologica estacion = new EstacionMeteorologica();
        AppMovil app = new AppMovil();
        PantallaLobby lobby = new PantallaLobby();

        estacion.agregarObservador(app);
        estacion.agregarObservador(lobby);

        estacion.registrarNuevaTemperatura(25.5f);
        estacion.registrarNuevaTemperatura(27.0f);
    }
}
