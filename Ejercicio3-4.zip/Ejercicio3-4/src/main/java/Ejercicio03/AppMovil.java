/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio03;

/**
 *
 * @author huatu
 */
public class AppMovil implements ObservadorClima {
    @Override
    public void actualizar(float temperatura) {
        mostrarTemperatura(temperatura);
    }

    public void mostrarTemperatura(float temp) {
        System.out.println("App Movil muestra temperatura: " + temp + "C");
    }
}