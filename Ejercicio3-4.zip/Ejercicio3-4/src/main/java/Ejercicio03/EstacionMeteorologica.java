/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Ejercicio03;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author huatu
 */
public class EstacionMeteorologica {
    private List<ObservadorClima> observadores = new ArrayList<>();
    private float temperaturaActual;

    public void agregarObservador(ObservadorClima observador) {
        observadores.add(observador);
    }

    public void eliminarObservador(ObservadorClima observador) {
        observadores.remove(observador);
    }

    public void registrarNuevaTemperatura(float nuevaTemp) {
        this.temperaturaActual = nuevaTemp;
        System.out.println("Sensor detecta nueva temperatura: " + nuevaTemp);
        notificarObservadores();
    }

    private void notificarObservadores() {
        for (ObservadorClima obs : observadores) {
            obs.actualizar(temperaturaActual);
        }
    }
}