package pe.edu.ferreteria.model;

/** 1. Clasifica productos por rubro (herramientas, electricidad, pintura...). */
public class Categoria {
    private final int id;
    private final String nombre;
    private final String descripcion;

    public Categoria(int id, String nombre, String descripcion) {
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Nombre de categoría requerido");
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion == null ? "" : descripcion;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }

    @Override
    public String toString() { return nombre; }
}
