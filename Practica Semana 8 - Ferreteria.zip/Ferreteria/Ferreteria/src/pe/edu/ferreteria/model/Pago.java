package pe.edu.ferreteria.model;

/** 5. Registra monto, medio de pago, estado y referencia de una venta. */
public class Pago {
    public enum Medio { EFECTIVO, TARJETA, YAPE, TRANSFERENCIA }
    public enum Estado { PENDIENTE, APROBADO, RECHAZADO }

    private final int id;
    private final Venta venta;
    private final double monto;
    private final Medio medio;
    private Estado estado = Estado.PENDIENTE;
    private String referencia;

    public Pago(int id, Venta venta, double monto, Medio medio) {
        if (venta == null) throw new IllegalArgumentException("Venta requerida");
        if (monto <= 0) throw new IllegalArgumentException("Monto inválido");
        if (medio == null) throw new IllegalArgumentException("Medio de pago requerido");
        this.id = id;
        this.venta = venta;
        this.monto = monto;
        this.medio = medio;
    }

    public void aprobar(String referencia) {
        exigirPendiente();
        this.estado = Estado.APROBADO;
        this.referencia = referencia;
    }

    public void rechazar() {
        exigirPendiente();
        this.estado = Estado.RECHAZADO;
    }

    private void exigirPendiente() {
        if (estado != Estado.PENDIENTE) throw new IllegalStateException("El pago ya fue procesado: " + estado);
    }

    public boolean estaAprobado() { return estado == Estado.APROBADO; }

    public int getId() { return id; }
    public Venta getVenta() { return venta; }
    public double getMonto() { return monto; }
    public Medio getMedio() { return medio; }
    public Estado getEstado() { return estado; }
    public String getReferencia() { return referencia; }

    @Override
    public String toString() {
        return "Pago#" + id + " " + medio + " S/ " + String.format("%.2f", monto) + " [" + estado + "]"
                + (referencia != null ? " ref=" + referencia : "");
    }
}
