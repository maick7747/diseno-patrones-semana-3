package pe.edu.ferreteria.model;

/** 2. Proveedor con código, RUC, razón social y estado. */
public class Proveedor {
    private final String codigo;
    private final String ruc;
    private final String razonSocial;
    private boolean activo;

    public Proveedor(String codigo, String ruc, String razonSocial, boolean activo) {
        if (codigo == null || codigo.isBlank()) throw new IllegalArgumentException("Código requerido");
        if (ruc == null || !ruc.matches("\\d{11}")) throw new IllegalArgumentException("RUC inválido (11 dígitos)");
        if (razonSocial == null || razonSocial.isBlank()) throw new IllegalArgumentException("Razón social requerida");
        this.codigo = codigo;
        this.ruc = ruc;
        this.razonSocial = razonSocial;
        this.activo = activo;
    }

    public String getCodigo() { return codigo; }
    public String getRuc() { return ruc; }
    public String getRazonSocial() { return razonSocial; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    @Override
    public String toString() {
        return codigo + " - " + razonSocial + " (RUC " + ruc + ", " + (activo ? "activo" : "inactivo") + ")";
    }
}
