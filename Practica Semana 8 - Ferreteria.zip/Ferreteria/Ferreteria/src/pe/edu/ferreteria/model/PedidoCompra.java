package pe.edu.ferreteria.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** 7. Orden de reposición a un proveedor. */
public class PedidoCompra {
    public enum Estado { CREADO, RECIBIDO }

    private final int id;
    private final Proveedor proveedor;
    private final Empleado empleado;
    private final List<DetallePedidoCompra> detalles = new ArrayList<>();
    private Estado estado = Estado.CREADO;

    public PedidoCompra(int id, Proveedor proveedor, Empleado empleado) {
        if (proveedor == null) throw new IllegalArgumentException("Proveedor requerido");
        if (!proveedor.isActivo()) throw new IllegalStateException("El proveedor está inactivo");
        this.id = id;
        this.proveedor = proveedor;
        this.empleado = empleado;
    }

    public void agregarDetalle(DetallePedidoCompra detalle) {
        if (detalle == null) throw new IllegalArgumentException("Detalle requerido");
        if (estado == Estado.RECIBIDO) throw new IllegalStateException("El pedido ya fue recibido");
        detalles.add(detalle);
    }

    public double calcularTotal() {
        return detalles.stream().mapToDouble(DetallePedidoCompra::subtotal).sum();
    }

    public void marcarRecibido() { this.estado = Estado.RECIBIDO; }

    public int getId() { return id; }
    public Proveedor getProveedor() { return proveedor; }
    public Empleado getEmpleado() { return empleado; }
    public Estado getEstado() { return estado; }
    public List<DetallePedidoCompra> getDetalles() { return Collections.unmodifiableList(detalles); }

    @Override
    public String toString() {
        return "Pedido#" + id + " a " + proveedor.getRazonSocial() + " [" + estado + "] total S/ "
                + String.format("%.2f", calcularTotal());
    }
}
