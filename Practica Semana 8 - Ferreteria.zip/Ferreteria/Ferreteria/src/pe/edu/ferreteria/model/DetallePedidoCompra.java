package pe.edu.ferreteria.model;

/** 8. Línea de un pedido de compra: producto, cantidad solicitada y costo. */
public class DetallePedidoCompra {
    private final Producto producto;
    private final int cantidad;
    private final double costoUnitario;

    public DetallePedidoCompra(Producto producto, int cantidad, double costoUnitario) {
        if (producto == null) throw new IllegalArgumentException("Producto requerido");
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad inválida");
        if (costoUnitario < 0) throw new IllegalArgumentException("Costo inválido");
        this.producto = producto;
        this.cantidad = cantidad;
        this.costoUnitario = costoUnitario;
    }

    public double subtotal() { return cantidad * costoUnitario; }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getCostoUnitario() { return costoUnitario; }
}
