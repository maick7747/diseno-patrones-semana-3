package pe.edu.ferreteria.model;

/** 3. Trabajador que registra una venta o compra. */
public class Empleado {
    private final String codigo;
    private final String nombre;
    private final String cargo;

    public Empleado(String codigo, String nombre, String cargo) {
        if (codigo == null || codigo.isBlank()) throw new IllegalArgumentException("Código requerido");
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Nombre requerido");
        if (cargo == null || cargo.isBlank()) throw new IllegalArgumentException("Cargo requerido");
        this.codigo = codigo;
        this.nombre = nombre;
        this.cargo = cargo;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public String getCargo() { return cargo; }

    @Override
    public String toString() { return codigo + " - " + nombre + " (" + cargo + ")"; }
}
