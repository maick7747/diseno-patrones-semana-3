package pe.edu.ferreteria.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Venta {
    private final int id;
    private final Cliente cliente;
    private final List<Producto> productos = new ArrayList<>();
    // AMPLIACIÓN: detalles y empleado (la API original sigue funcionando)
    private final List<DetalleVenta> detalles = new ArrayList<>();
    private Empleado empleado;

    public Venta(int id, Cliente cliente) {
        this.id = id;
        this.cliente = cliente;
    }

    public void agregarProducto(Producto producto) {
        if (producto == null) throw new IllegalArgumentException("Producto requerido");
        productos.add(producto);
    }

    public void agregarDetalle(DetalleVenta detalle) {
        if (detalle == null) throw new IllegalArgumentException("Detalle requerido");
        detalles.add(detalle);
    }

    public double calcularTotal() {
        double totalProductos = productos.stream().mapToDouble(Producto::getPrecio).sum();
        double totalDetalles = detalles.stream().mapToDouble(DetalleVenta::subtotal).sum();
        return totalProductos + totalDetalles;
    }

    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public List<Producto> getProductos() { return Collections.unmodifiableList(productos); }
    public List<DetalleVenta> getDetalles() { return Collections.unmodifiableList(detalles); }
    public Empleado getEmpleado() { return empleado; }
    public void setEmpleado(Empleado empleado) { this.empleado = empleado; }
}
