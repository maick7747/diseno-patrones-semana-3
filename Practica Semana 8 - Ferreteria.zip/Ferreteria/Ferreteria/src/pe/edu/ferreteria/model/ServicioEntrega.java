package pe.edu.ferreteria.model;

/** 9. Despacho: dirección, costo y estado. */
public class ServicioEntrega {
    public enum Estado { PENDIENTE, PROGRAMADA, DESPACHADA, ENTREGADA }

    private final int id;
    private final String direccion;
    private final double costo;
    private Estado estado = Estado.PENDIENTE;

    public ServicioEntrega(int id, String direccion, double costo) {
        if (direccion == null || direccion.isBlank()) throw new IllegalArgumentException("Dirección requerida");
        if (costo < 0) throw new IllegalArgumentException("Costo inválido");
        this.id = id;
        this.direccion = direccion;
        this.costo = costo;
    }

    public void programar() { transicion(Estado.PENDIENTE, Estado.PROGRAMADA); }
    public void despachar() { transicion(Estado.PROGRAMADA, Estado.DESPACHADA); }
    public void entregar()  { transicion(Estado.DESPACHADA, Estado.ENTREGADA); }

    private void transicion(Estado esperado, Estado nuevo) {
        if (estado != esperado)
            throw new IllegalStateException("No se puede pasar a " + nuevo + " desde " + estado);
        estado = nuevo;
    }

    public int getId() { return id; }
    public String getDireccion() { return direccion; }
    public double getCosto() { return costo; }
    public Estado getEstado() { return estado; }

    @Override
    public String toString() {
        return "Entrega#" + id + " -> " + direccion + " (S/ " + String.format("%.2f", costo) + ") [" + estado + "]";
    }
}
