package pe.edu.ferreteria.model;

import java.time.LocalDate;

/** 6. Boleta/factura. Solo puede generarse a partir de un pago APROBADO. */
public class Comprobante {
    public enum Tipo { BOLETA, FACTURA }

    private final String numero;
    private final Tipo tipo;
    private final LocalDate fecha;
    private final double total;
    private final Cliente cliente;

    public Comprobante(String numero, Tipo tipo, Pago pago, Cliente cliente) {
        if (numero == null || numero.isBlank()) throw new IllegalArgumentException("Número requerido");
        if (tipo == null) throw new IllegalArgumentException("Tipo requerido");
        if (pago == null || !pago.estaAprobado())
            throw new IllegalStateException("No se puede emitir comprobante sin un pago aprobado");
        if (cliente == null) throw new IllegalArgumentException("Cliente requerido");
        this.numero = numero;
        this.tipo = tipo;
        this.fecha = LocalDate.now();
        this.total = pago.getMonto();
        this.cliente = cliente;
    }

    public String getNumero() { return numero; }
    public Tipo getTipo() { return tipo; }
    public LocalDate getFecha() { return fecha; }
    public double getTotal() { return total; }
    public Cliente getCliente() { return cliente; }

    @Override
    public String toString() {
        return tipo + " " + numero + " | " + fecha + " | " + cliente.getNombre() + " | S/ " + String.format("%.2f", total);
    }
}
