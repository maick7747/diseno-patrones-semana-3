package pe.edu.ferreteria.ejercicio2;

public class ReposicionConAdapter {                                   // CLIENTE: sin conversiones de ID ni cajas
    private final CatalogoProveedor catalogo;
    public ReposicionConAdapter(CatalogoProveedor catalogo) { this.catalogo = catalogo; }
    public boolean hayStockExterno(String codigo) { return catalogo.consultarStock(codigo) > 0; }
}
