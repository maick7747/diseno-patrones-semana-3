package pe.edu.ferreteria.ejercicio2;

/** Segundo proveedor que ya implementa el Target. */
public class ProveedorNuevo implements CatalogoProveedor {
    @Override
    public int consultarStock(String codigo) { return "P-200".equals(codigo) ? 15 : 0; }
}
