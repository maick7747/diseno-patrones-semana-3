package pe.edu.ferreteria.ejercicio2;

public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("Sin patrón  P-100: " + new ReposicionSinAdapter().hayStockExterno("P-100"));

        CatalogoProveedor antiguo = new ProveedorAntiguoAdapter(new ProveedorAntiguo());
        CatalogoProveedor nuevo = new ProveedorNuevo();

        System.out.println("Antiguo (adaptado) P-100 -> " + antiguo.consultarStock("P-100") + " unidades");
        System.out.println("Antiguo (adaptado) P-200 -> " + antiguo.consultarStock("P-200") + " unidades");
        System.out.println("Nuevo P-200 -> " + nuevo.consultarStock("P-200") + " unidades");

        ReposicionConAdapter conAntiguo = new ReposicionConAdapter(antiguo);
        ReposicionConAdapter conNuevo = new ReposicionConAdapter(nuevo);
        System.out.println("¿Stock P-100 en proveedor antiguo? " + conAntiguo.hayStockExterno("P-100"));
        System.out.println("¿Stock P-200 en proveedor nuevo?   " + conNuevo.hayStockExterno("P-200"));
    }
}
