package pe.edu.ferreteria.ejercicio2;

// ---------- Versión CON Adapter ----------
public interface CatalogoProveedor {                                  // TARGET
    int consultarStock(String codigo);                         // siempre en UNIDADES
}
