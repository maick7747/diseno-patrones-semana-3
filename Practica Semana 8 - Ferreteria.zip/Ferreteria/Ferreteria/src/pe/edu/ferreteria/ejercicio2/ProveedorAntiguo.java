package pe.edu.ferreteria.ejercicio2;

/** ADAPTEE modificado: ahora devuelve existencias en CAJAS. */
public class ProveedorAntiguo {
    public int existencias(int idExterno) { return idExterno == 100 ? 4 : 0; }   // 4 cajas
}
