package pe.edu.ferreteria.ejercicio2;

public class ReposicionSinAdapter {
    public boolean hayStockExterno(String codigo) {
        ProveedorAntiguoSimple proveedor = new ProveedorAntiguoSimple();
        int id = Integer.parseInt(codigo.replace("P-", ""));   // conversión mezclada con la lógica
        return proveedor.existencias(id) > 0;
    }
}
