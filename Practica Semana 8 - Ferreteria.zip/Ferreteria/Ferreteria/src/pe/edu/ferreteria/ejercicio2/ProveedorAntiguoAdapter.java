package pe.edu.ferreteria.ejercicio2;

public class ProveedorAntiguoAdapter implements CatalogoProveedor {   // ADAPTER
    private static final int UNIDADES_POR_CAJA = 10;
    private final ProveedorAntiguo proveedor;
    public ProveedorAntiguoAdapter(ProveedorAntiguo proveedor) { this.proveedor = proveedor; }

    @Override
    public int consultarStock(String codigo) {
        int id = Integer.parseInt(codigo.replace("P-", ""));          // traduce identificador
        return proveedor.existencias(id) * UNIDADES_POR_CAJA;         // traduce cajas -> unidades
    }
}
