package pe.edu.ferreteria.ejercicio2;

// ---------- Versión SIN patrón ----------
public class ProveedorAntiguoSimple {
    public int existencias(int idExterno) { return idExterno == 100 ? 40 : 0; }
}
