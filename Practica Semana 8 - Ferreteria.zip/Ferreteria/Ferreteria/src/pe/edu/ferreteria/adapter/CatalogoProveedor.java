package pe.edu.ferreteria.adapter;

/** TARGET del Adapter de proveedores: consulta de stock por código interno (ej. "P-100"), en unidades. */
public interface CatalogoProveedor {
    int consultarStock(String codigoProducto);
}
