package pe.edu.ferreteria.adapter;

/**
 * 11. ADAPTER: implementa ProcesadorPago (Target) y delega en PasarelaPagoLegacy (Adaptee),
 * traduciendo soles -> céntimos, asignando la moneda "PEN" e interpretando el código de respuesta.
 * El resto de la aplicación nunca llama a la API legado.
 */
public class PasarelaPagoLegacyAdapter implements ProcesadorPago {
    private static final String MONEDA = "PEN";
    private final PasarelaPagoLegacy pasarela;

    public PasarelaPagoLegacyAdapter(PasarelaPagoLegacy pasarela) {
        if (pasarela == null) throw new IllegalArgumentException("Pasarela requerida");
        this.pasarela = pasarela;
    }

    @Override
    public boolean procesar(double montoEnSoles) {
        long centimos = Math.round(montoEnSoles * 100);
        return pasarela.cobrar(centimos, MONEDA) == 0;
    }
}
