package pe.edu.ferreteria.adapter;

/**
 * ADAPTEE simulado: API antigua. Trabaja en CÉNTIMOS (long) y con código de moneda ISO,
 * y responde con un código numérico (0 = OK). Límite de la pasarela: S/ 1000.
 */
public class PasarelaPagoLegacy {
    public int cobrar(long montoCentimos, String codigoMoneda) {
        System.out.println("  [Pasarela legacy] cobrando " + montoCentimos + " céntimos " + codigoMoneda);
        if (!"PEN".equals(codigoMoneda)) return 2;      // moneda no soportada
        if (montoCentimos <= 0) return 3;               // monto inválido
        if (montoCentimos > 100_000) return 1;          // excede el límite
        return 0;
    }
}
