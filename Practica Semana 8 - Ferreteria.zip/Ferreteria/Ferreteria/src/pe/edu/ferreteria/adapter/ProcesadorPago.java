package pe.edu.ferreteria.adapter;

/** TARGET del Adapter de pagos: la interfaz que el sistema nuevo espera. */
public interface ProcesadorPago {
    /** Procesa un cobro expresado en soles. @return true si fue aprobado. */
    boolean procesar(double montoEnSoles);
}
