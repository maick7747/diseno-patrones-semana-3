package pe.edu.ferreteria.adapter;

import java.util.HashMap;
import java.util.Map;

/** ADAPTEE simulado: sistema antiguo que usa IDs numéricos y reporta existencias en CAJAS. */
public class ProveedorLegacy {
    private final Map<Integer, Integer> cajas = new HashMap<>();

    public ProveedorLegacy() {
        cajas.put(100, 4);   // martillos
        cajas.put(200, 2);   // taladros
        cajas.put(300, 0);   // cemento sin stock
    }

    public int existenciasEnCajas(int idExterno) {
        return cajas.getOrDefault(idExterno, 0);
    }
}
