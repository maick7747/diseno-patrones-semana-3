package pe.edu.ferreteria.adapter;

/**
 * 12. ADAPTER: traduce el identificador interno "P-100" al ID numérico 100 que espera el
 * proveedor legado y convierte cajas -> unidades.
 */
public class ProveedorLegacyAdapter implements CatalogoProveedor {
    public static final int UNIDADES_POR_CAJA = 10;
    private final ProveedorLegacy proveedor;

    public ProveedorLegacyAdapter(ProveedorLegacy proveedor) {
        if (proveedor == null) throw new IllegalArgumentException("Proveedor requerido");
        this.proveedor = proveedor;
    }

    @Override
    public int consultarStock(String codigoProducto) {
        if (codigoProducto == null || !codigoProducto.matches("P-\\d+"))
            throw new IllegalArgumentException("Código con formato inválido (se espera P-###): " + codigoProducto);
        int idExterno = Integer.parseInt(codigoProducto.substring(2));
        return proveedor.existenciasEnCajas(idExterno) * UNIDADES_POR_CAJA;
    }
}
