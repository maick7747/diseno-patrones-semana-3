package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.adapter.CatalogoProveedor;
import pe.edu.ferreteria.model.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 15. FACADE de compras: valida proveedor activo, consulta su catálogo (vía Adapter), crea el pedido,
 * agrega el detalle y, al simular la recepción, actualiza el stock.
 */
public class ComprasFacade {
    /** Costo simulado de compra = 70 % del precio de venta. */
    private static final double RATIO_COSTO = 0.70;

    private final Empleado empleado;
    private final InventarioFacade inventario;
    private final CatalogoProveedor catalogo;
    private final List<PedidoCompra> pedidos = new ArrayList<>();
    private int siguientePedido = 1;

    public ComprasFacade(Empleado empleado, InventarioFacade inventario, CatalogoProveedor catalogo) {
        if (empleado == null || inventario == null || catalogo == null)
            throw new IllegalArgumentException("Empleado, inventario y catálogo son requeridos");
        this.empleado = empleado;
        this.inventario = inventario;
        this.catalogo = catalogo;
    }

    /** @throws IllegalStateException si el proveedor está inactivo o no tiene stock suficiente. */
    public PedidoCompra reponerProducto(Proveedor proveedor, Producto producto, int cantidad) {
        if (proveedor == null) throw new IllegalArgumentException("Proveedor requerido");
        if (producto == null) throw new IllegalArgumentException("Producto requerido");
        if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor a cero");

        if (!proveedor.isActivo())
            throw new IllegalStateException("Proveedor inactivo: " + proveedor.getRazonSocial());

        int disponible = catalogo.consultarStock(producto.getCodigo());
        if (disponible < cantidad)
            throw new IllegalStateException("El proveedor solo dispone de " + disponible + " unidades de "
                    + producto.getCodigo() + " (solicitado: " + cantidad + ")");

        PedidoCompra pedido = new PedidoCompra(siguientePedido++, proveedor, empleado);
        pedido.agregarDetalle(new DetallePedidoCompra(producto, cantidad, producto.getPrecio() * RATIO_COSTO));

        // Simulación de recepción: ingresa al inventario y cierra el pedido
        inventario.ingresarStock(producto.getCodigo(), cantidad);
        pedido.marcarRecibido();

        pedidos.add(pedido);
        return pedido;
    }

    public List<PedidoCompra> getPedidos() { return Collections.unmodifiableList(pedidos); }
}
