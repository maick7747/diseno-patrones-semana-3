package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.model.Categoria;
import pe.edu.ferreteria.model.Producto;
import pe.edu.ferreteria.service.Inventario;

/**
 * 14. FACADE de inventario: operaciones simples y validaciones comunes (código, cantidad,
 * producto registrado) para el cliente. Inventario sigue disponible para quien necesite control fino.
 */
public class InventarioFacade {
    private final Inventario inventario;

    public InventarioFacade(Inventario inventario) {
        if (inventario == null) throw new IllegalArgumentException("Inventario requerido");
        this.inventario = inventario;
    }

    public void registrarProducto(Producto producto, Categoria categoria, int cantidadInicial) {
        if (producto == null) throw new IllegalArgumentException("Producto requerido");
        if (categoria != null) producto.setCategoria(categoria);
        inventario.registrarProducto(producto, cantidadInicial);
    }

    public void registrarProducto(Producto producto, int cantidadInicial) {
        registrarProducto(producto, null, cantidadInicial);
    }

    public Producto buscarProducto(String codigo) {
        validarCodigo(codigo);
        return inventario.buscar(codigo);
    }

    public int consultarDisponibilidad(String codigo) {
        exigirRegistrado(codigo);
        return inventario.consultarStock(codigo);
    }

    public boolean hayDisponibilidad(String codigo, int cantidad) {
        validarCodigo(codigo);
        return inventario.buscar(codigo) != null && inventario.hayStock(codigo, cantidad);
    }

    public void ingresarStock(String codigo, int cantidad) {
        exigirRegistrado(codigo);
        exigirCantidadPositiva(cantidad);
        inventario.ingresar(codigo, cantidad);
    }

    public void retirarStock(String codigo, int cantidad) {
        exigirRegistrado(codigo);
        exigirCantidadPositiva(cantidad);
        if (!inventario.hayStock(codigo, cantidad))
            throw new IllegalStateException("Stock insuficiente para " + codigo
                    + " (disponible: " + inventario.consultarStock(codigo) + ", solicitado: " + cantidad + ")");
        inventario.retirar(codigo, cantidad);
    }

    private void validarCodigo(String codigo) {
        if (codigo == null || codigo.isBlank()) throw new IllegalArgumentException("Código requerido");
    }

    private void exigirRegistrado(String codigo) {
        validarCodigo(codigo);
        if (inventario.buscar(codigo) == null) throw new IllegalArgumentException("Producto no registrado: " + codigo);
    }

    private void exigirCantidadPositiva(int cantidad) {
        if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor a cero");
    }
}
