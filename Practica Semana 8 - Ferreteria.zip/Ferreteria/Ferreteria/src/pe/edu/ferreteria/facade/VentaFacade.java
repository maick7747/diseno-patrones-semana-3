package pe.edu.ferreteria.facade;

import pe.edu.ferreteria.adapter.ProcesadorPago;
import pe.edu.ferreteria.model.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * 13. FACADE de venta: un solo método coordina stock, venta, pago (vía Adapter), retiro de stock,
 * comprobante y entrega opcional. El cliente no conoce el orden ni las clases internas.
 */
public class VentaFacade {
    public static final double COSTO_ENTREGA_DEFECTO = 10.0;

    /** Resultado de la operación (en lugar de un simple boolean). */
    public static class ResultadoVenta {
        private final boolean exitosa;
        private final String mensaje;
        private final Venta venta;
        private final Pago pago;
        private final Comprobante comprobante;
        private final ServicioEntrega entrega;

        private ResultadoVenta(boolean exitosa, String mensaje, Venta venta, Pago pago,
                               Comprobante comprobante, ServicioEntrega entrega) {
            this.exitosa = exitosa; this.mensaje = mensaje; this.venta = venta;
            this.pago = pago; this.comprobante = comprobante; this.entrega = entrega;
        }
        static ResultadoVenta ok(Venta v, Pago p, Comprobante c, ServicioEntrega e) {
            return new ResultadoVenta(true, "Venta registrada", v, p, c, e);
        }
        static ResultadoVenta fallo(String mensaje, Venta v, Pago p) {
            return new ResultadoVenta(false, mensaje, v, p, null, null);
        }
        public boolean isExitosa() { return exitosa; }
        public String getMensaje() { return mensaje; }
        public Venta getVenta() { return venta; }
        public Pago getPago() { return pago; }
        public Comprobante getComprobante() { return comprobante; }
        public ServicioEntrega getEntrega() { return entrega; }
    }

    private final Empleado empleado;
    private final InventarioFacade inventario;
    private final ProcesadorPago procesadorPago;
    private final List<Venta> ventasRegistradas = new ArrayList<>();
    private int siguienteVenta = 100;
    private int siguientePago = 1;
    private int siguienteEntrega = 1;

    public VentaFacade(Empleado empleado, InventarioFacade inventario, ProcesadorPago procesadorPago) {
        if (empleado == null || inventario == null || procesadorPago == null)
            throw new IllegalArgumentException("Empleado, inventario y procesador de pago son requeridos");
        this.empleado = empleado;
        this.inventario = inventario;
        this.procesadorPago = procesadorPago;
    }

    /** Firma mínima pedida: la dirección de entrega queda "por confirmar". */
    public ResultadoVenta procesarVenta(Cliente cliente, Map<String, Integer> items,
                                        Pago.Medio medioPago, boolean requiereEntrega) {
        return procesarVenta(cliente, items, medioPago, requiereEntrega,
                requiereEntrega ? "Dirección por confirmar con el cliente" : null);
    }

    public ResultadoVenta procesarVenta(Cliente cliente, Map<String, Integer> items,
                                        Pago.Medio medioPago, boolean requiereEntrega, String direccion) {
        if (cliente == null) throw new IllegalArgumentException("Cliente requerido");
        if (items == null || items.isEmpty()) throw new IllegalArgumentException("La venta necesita al menos un ítem");
        if (medioPago == null) throw new IllegalArgumentException("Medio de pago requerido");

        // 1) Verificar stock de todos los ítems
        for (Map.Entry<String, Integer> item : items.entrySet()) {
            if (inventario.buscarProducto(item.getKey()) == null)
                return ResultadoVenta.fallo("Producto no registrado: " + item.getKey(), null, null);
            if (!inventario.hayDisponibilidad(item.getKey(), item.getValue()))
                return ResultadoVenta.fallo("Stock insuficiente para " + item.getKey(), null, null);
        }

        // 2) Construir la venta
        Venta venta = new Venta(siguienteVenta++, cliente);
        venta.setEmpleado(empleado);
        for (Map.Entry<String, Integer> item : items.entrySet()) {
            Producto p = inventario.buscarProducto(item.getKey());
            venta.agregarDetalle(new DetalleVenta(p, item.getValue(), p.getPrecio()));
        }
        double total = venta.calcularTotal();
        ServicioEntrega entrega = null;
        if (requiereEntrega) {
            entrega = new ServicioEntrega(siguienteEntrega++, direccion, COSTO_ENTREGA_DEFECTO);
            total += entrega.getCosto();
        }

        // 3) Procesar el pago (a través del Adapter, sin conocer la API legado)
        Pago pago = new Pago(siguientePago++, venta, total, medioPago);
        if (!procesadorPago.procesar(total)) {
            pago.rechazar();
            return ResultadoVenta.fallo("Pago rechazado", venta, pago);   // no se toca el stock
        }
        pago.aprobar("REF-" + venta.getId());

        // 4) Retirar stock (solo con pago aprobado)
        for (Map.Entry<String, Integer> item : items.entrySet())
            inventario.retirarStock(item.getKey(), item.getValue());

        // 5) Emitir comprobante
        Comprobante comprobante = new Comprobante(
                String.format("B001-%06d", venta.getId()), Comprobante.Tipo.BOLETA, pago, cliente);

        // 6) Programar entrega solo si corresponde
        if (entrega != null) entrega.programar();

        ventasRegistradas.add(venta);
        return ResultadoVenta.ok(venta, pago, comprobante, entrega);
    }

    public List<Venta> getVentasRegistradas() {
        return Collections.unmodifiableList(ventasRegistradas);
    }
}
