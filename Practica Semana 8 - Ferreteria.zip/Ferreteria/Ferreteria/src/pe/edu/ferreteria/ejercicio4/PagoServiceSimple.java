package pe.edu.ferreteria.ejercicio4;

public class PagoServiceSimple {
    public boolean cobrar(double total) { return total > 0 && total <= 1000; }
}
