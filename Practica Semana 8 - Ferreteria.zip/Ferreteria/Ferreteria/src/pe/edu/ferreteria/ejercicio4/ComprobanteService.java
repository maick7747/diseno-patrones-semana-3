package pe.edu.ferreteria.ejercicio4;

public class ComprobanteService {
    public void emitir(double total) { System.out.println("Comprobante emitido por S/ " + total); }
}
