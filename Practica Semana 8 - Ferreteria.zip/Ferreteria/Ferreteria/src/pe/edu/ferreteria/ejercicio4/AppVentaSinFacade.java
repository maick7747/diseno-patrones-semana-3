package pe.edu.ferreteria.ejercicio4;

// ---------- Versión SIN patrón: el cliente coordina todo ----------
public class AppVentaSinFacade {
    static void ejecutar() {
        InventarioService inventario = new InventarioService();
        PagoServiceSimple pago = new PagoServiceSimple();
        ComprobanteService comprobante = new ComprobanteService();
        String codigo = "TAL-001"; int cantidad = 2; double total = 50.0;

        if (!inventario.hayStock(codigo, cantidad)) { System.out.println("Stock insuficiente"); return; }
        if (!pago.cobrar(total)) { System.out.println("Pago rechazado"); return; }
        inventario.descontar(codigo, cantidad);
        comprobante.emitir(total);
        System.out.println("Venta terminada");
    }
}
