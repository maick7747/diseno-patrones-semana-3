package pe.edu.ferreteria.ejercicio4;

/** NUEVA clase del subsistema (parte de la tarea). */
public class ServicioEntrega {
    public void programar(String codigo, int cantidad) {
        System.out.println("Entrega programada: " + cantidad + " x " + codigo);
    }
}
