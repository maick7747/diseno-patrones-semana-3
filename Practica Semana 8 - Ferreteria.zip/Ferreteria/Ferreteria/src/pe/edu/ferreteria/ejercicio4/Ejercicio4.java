package pe.edu.ferreteria.ejercicio4;

public class Ejercicio4 {
    public static void main(String[] args) {
        System.out.println("== Sin Facade ==");
        AppVentaSinFacade.ejecutar();

        InventarioService inventario = new InventarioService();
        VentaFacade facade = new VentaFacade(inventario, new PagoServiceSimple(),
                new ComprobanteService(), new ServicioEntrega());

        System.out.println("\n== Con Facade, sin entrega ==");
        System.out.println(facade.realizarVenta("TAL-001", 2, 50.0));

        System.out.println("\n== Con Facade, con entrega ==");
        System.out.println(facade.realizarVenta("TAL-001", 3, 75.0, true));

        System.out.println("\n== Stock insuficiente ==");
        System.out.println(facade.realizarVenta("TAL-001", 99, 10.0, true));
        System.out.println("Stock final TAL-001: " + inventario.stock("TAL-001"));
    }
}
