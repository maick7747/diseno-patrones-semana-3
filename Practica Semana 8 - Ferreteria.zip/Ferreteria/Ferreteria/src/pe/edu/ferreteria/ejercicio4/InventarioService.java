package pe.edu.ferreteria.ejercicio4;

import java.util.HashMap;
import java.util.Map;

// ---------- Subsistema ----------
public class InventarioService {
    private final Map<String, Integer> stock = new HashMap<>();
    public InventarioService() { stock.put("TAL-001", 10); }
    public boolean hayStock(String codigo, int cantidad) { return stock.getOrDefault(codigo, 0) >= cantidad; }
    public void descontar(String codigo, int cantidad) { stock.merge(codigo, -cantidad, Integer::sum); }
    public int stock(String codigo) { return stock.getOrDefault(codigo, 0); }
}
