package pe.edu.ferreteria.ejercicio4;

// ---------- Versión CON Facade ----------
public class VentaFacade {
    private final InventarioService inventario;
    private final PagoServiceSimple pago;
    private final ComprobanteService comprobante;
    private final ServicioEntrega entrega;

    public VentaFacade(InventarioService inventario, PagoServiceSimple pago,
                       ComprobanteService comprobante, ServicioEntrega entrega) {
        this.inventario = inventario;
        this.pago = pago;
        this.comprobante = comprobante;
        this.entrega = entrega;
    }

    /** Versión original (sin entrega). */
    public boolean realizarVenta(String codigo, int cantidad, double total) {
        return realizarVenta(codigo, cantidad, total, false);
    }

    /** La entrega se invoca SOLO cuando corresponde. */
    public boolean realizarVenta(String codigo, int cantidad, double total, boolean requiereEntrega) {
        if (!inventario.hayStock(codigo, cantidad)) return false;
        if (!pago.cobrar(total)) return false;
        inventario.descontar(codigo, cantidad);
        comprobante.emitir(total);
        if (requiereEntrega) entrega.programar(codigo, cantidad);
        return true;
    }
}
