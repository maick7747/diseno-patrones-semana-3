package pe.edu.ferreteria.ejercicio1;

public class PagoLegacyAdapter implements PagoService {      // ADAPTER
    private final PagoLegacy adaptee;
    public PagoLegacyAdapter(PagoLegacy adaptee) { this.adaptee = adaptee; }
    @Override
    public boolean pagarEnSoles(double monto) { return adaptee.cobrar(monto, "PEN"); }
}
