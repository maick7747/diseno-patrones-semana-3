package pe.edu.ferreteria.ejercicio1;

/** Implementación nativa: ya cumple el Target, no necesita adaptador. */
public class PagoEfectivo implements PagoService {
    @Override
    public boolean pagarEnSoles(double monto) {
        System.out.println("Cobro en efectivo: S/ " + monto);
        return true;
    }
}
