package pe.edu.ferreteria.ejercicio1;

public class CajaSinAdapter {
    private final PagoLegacy pagoLegacy = new PagoLegacy();
    public void pagar(double total) {
        boolean ok = pagoLegacy.cobrar(total, "PEN");  // el cliente conoce la API antigua
        System.out.println(ok ? "Venta pagada" : "Pago rechazado");
    }
}
