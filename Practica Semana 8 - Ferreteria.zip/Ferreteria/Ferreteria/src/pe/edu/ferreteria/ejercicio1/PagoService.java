package pe.edu.ferreteria.ejercicio1;

// ---------- Versión CON Adapter ----------
public interface PagoService {                               // TARGET
    boolean pagarEnSoles(double monto);
}
