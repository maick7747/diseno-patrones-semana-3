package pe.edu.ferreteria.ejercicio1;

// ---------- Tarea: cambiar PagoLegacy por otra implementación SIN tocar CajaConAdapter ----------
/** Otra librería externa distinta: trabaja en céntimos y devuelve un código de estado. */
public class PasarelaModerna {
    public String pay(long centimos) {
        System.out.println("Pasarela moderna: " + centimos + " céntimos");
        return "APPROVED";
    }
}
