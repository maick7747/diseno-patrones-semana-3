package pe.edu.ferreteria.ejercicio1;

public class Ejercicio1 {
    public static void main(String[] args) {
        System.out.println("== Sin patrón ==");
        new CajaSinAdapter().pagar(120.0);

        System.out.println("\n== Con Adapter (legacy) ==");
        new CajaConAdapter(new PagoLegacyAdapter(new PagoLegacy())).pagar(120.0);

        System.out.println("\n== Misma Caja, otra pasarela ==");
        new CajaConAdapter(new PasarelaModernaAdapter(new PasarelaModerna())).pagar(120.0);

        System.out.println("\n== Misma Caja, implementación nativa ==");
        new CajaConAdapter(new PagoEfectivo()).pagar(120.0);
    }
}
