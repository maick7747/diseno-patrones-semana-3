package pe.edu.ferreteria.ejercicio1;

public class PasarelaModernaAdapter implements PagoService {
    private final PasarelaModerna adaptee;
    public PasarelaModernaAdapter(PasarelaModerna adaptee) { this.adaptee = adaptee; }
    @Override
    public boolean pagarEnSoles(double monto) {
        return "APPROVED".equals(adaptee.pay(Math.round(monto * 100)));
    }
}
