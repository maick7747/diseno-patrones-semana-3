package pe.edu.ferreteria.ejercicio1;

// ---------- Versión SIN patrón ----------
public class PagoLegacy {                                    // ADAPTEE
    public boolean cobrar(double monto, String moneda) {
        System.out.println("Pago legacy: " + monto + " " + moneda);
        return true;
    }
}
