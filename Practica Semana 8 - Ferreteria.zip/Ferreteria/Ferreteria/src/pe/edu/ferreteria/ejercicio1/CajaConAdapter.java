package pe.edu.ferreteria.ejercicio1;

public class CajaConAdapter {                                // CLIENTE
    private final PagoService pagoService;
    public CajaConAdapter(PagoService pagoService) { this.pagoService = pagoService; }
    public void pagar(double total) {
        boolean ok = pagoService.pagarEnSoles(total);
        System.out.println(ok ? "Venta pagada" : "Pago rechazado");
    }
}
