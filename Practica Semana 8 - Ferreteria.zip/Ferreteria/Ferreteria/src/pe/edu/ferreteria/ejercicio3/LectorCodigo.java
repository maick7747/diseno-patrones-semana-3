package pe.edu.ferreteria.ejercicio3;

// ---------- Versión CON Adapter ----------
public interface LectorCodigo {                                       // TARGET
    String leerCodigo();
}
