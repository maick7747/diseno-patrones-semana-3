package pe.edu.ferreteria.ejercicio3;

import java.nio.charset.StandardCharsets;

// ---------- Versión SIN patrón ----------
public class LectorLegacy {                                           // ADAPTEE
    public byte[] leerBytes() { return "TAL-001".getBytes(StandardCharsets.UTF_8); }
}
