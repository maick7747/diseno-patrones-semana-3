package pe.edu.ferreteria.ejercicio3;

public class Ejercicio3 {
    public static void main(String[] args) {
        System.out.println("Sin patrón: " + new PuntoVentaSinAdapter().capturarCodigo());

        // El mismo PuntoVentaConAdapter funciona con ambos dispositivos
        PuntoVentaConAdapter pvAntiguo = new PuntoVentaConAdapter(new LectorLegacyAdapter(new LectorLegacy()));
        PuntoVentaConAdapter pvNuevo = new PuntoVentaConAdapter(new LectorInalambricoSimulado());

        System.out.println("Dispositivo antiguo -> " + pvAntiguo.capturarCodigo());
        System.out.println("Dispositivo nuevo   -> " + pvNuevo.capturarCodigo());
    }
}
