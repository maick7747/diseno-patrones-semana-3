package pe.edu.ferreteria.ejercicio3;

import java.nio.charset.StandardCharsets;

public class PuntoVentaSinAdapter {
    private final LectorLegacy lector = new LectorLegacy();
    public String capturarCodigo() { return new String(lector.leerBytes(), StandardCharsets.UTF_8); }
}
