package pe.edu.ferreteria.ejercicio3;

/** Segundo lector simulado que ya implementa LectorCodigo (dispositivo nuevo). */
public class LectorInalambricoSimulado implements LectorCodigo {
    @Override
    public String leerCodigo() { return "ELE-045"; }
}
