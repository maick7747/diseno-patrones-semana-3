package pe.edu.ferreteria.ejercicio3;

public class PuntoVentaConAdapter {                                   // CLIENTE
    private final LectorCodigo lector;
    public PuntoVentaConAdapter(LectorCodigo lector) { this.lector = lector; }
    public String capturarCodigo() { return lector.leerCodigo(); }
}
