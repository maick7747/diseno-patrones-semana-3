package pe.edu.ferreteria.ejercicio3;

import java.nio.charset.StandardCharsets;

public class LectorLegacyAdapter implements LectorCodigo {            // ADAPTER
    private final LectorLegacy lector;
    public LectorLegacyAdapter(LectorLegacy lector) { this.lector = lector; }
    @Override
    public String leerCodigo() { return new String(lector.leerBytes(), StandardCharsets.UTF_8); }
}
