package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.DetalleVenta;
import pe.edu.ferreteria.model.Venta;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** 10. Métricas sobre una colección de ventas. */
public class ReporteVentas {
    private final List<Venta> ventas;

    public ReporteVentas(Collection<Venta> ventas) {
        if (ventas == null) throw new IllegalArgumentException("Ventas requeridas");
        this.ventas = new ArrayList<>(ventas);
    }

    public double totalVendido() {
        return ventas.stream().mapToDouble(Venta::calcularTotal).sum();
    }

    public int numeroVentas() { return ventas.size(); }

    public double ticketPromedio() {
        return ventas.isEmpty() ? 0.0 : totalVendido() / ventas.size();
    }

    public int productosVendidos() {
        int unidades = 0;
        for (Venta v : ventas) {
            unidades += v.getProductos().size();
            for (DetalleVenta d : v.getDetalles()) unidades += d.getCantidad();
        }
        return unidades;
    }

    public void imprimir() {
        System.out.println("=== REPORTE DE VENTAS ===");
        System.out.println("Número de ventas  : " + numeroVentas());
        System.out.println("Productos vendidos: " + productosVendidos());
        System.out.println("Total vendido     : S/ " + String.format("%.2f", totalVendido()));
        System.out.println("Ticket promedio   : S/ " + String.format("%.2f", ticketPromedio()));
    }
}
