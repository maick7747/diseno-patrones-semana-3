package pe.edu.ferreteria.app;

import pe.edu.ferreteria.adapter.PasarelaPagoLegacy;
import pe.edu.ferreteria.adapter.PasarelaPagoLegacyAdapter;
import pe.edu.ferreteria.adapter.ProcesadorPago;
import pe.edu.ferreteria.adapter.ProveedorLegacy;
import pe.edu.ferreteria.adapter.ProveedorLegacyAdapter;
import pe.edu.ferreteria.facade.ComprasFacade;
import pe.edu.ferreteria.facade.InventarioFacade;
import pe.edu.ferreteria.facade.VentaFacade;
import pe.edu.ferreteria.facade.VentaFacade.ResultadoVenta;
import pe.edu.ferreteria.model.*;
import pe.edu.ferreteria.service.Inventario;
import pe.edu.ferreteria.service.ReporteVentas;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FerreteriaApp {
    public static void main(String[] args) {
        // ===================== CÓDIGO BASE ORIGINAL (sin cambios) =====================
        Inventario inventario = new Inventario();
        Producto martillo = new Producto("P-100", "Martillo", 35.90);
        Producto taladro = new Producto("P-200", "Taladro", 249.90);
        inventario.registrarProducto(martillo, 10);
        inventario.registrarProducto(taladro, 5);

        Cliente cliente = new Cliente("45879632", "Ana Torres");
        Venta venta = new Venta(1, cliente);
        if (inventario.hayStock("P-100", 1)) {
            venta.agregarProducto(martillo);
            inventario.retirar("P-100", 1);
        }
        System.out.println("Cliente: " + venta.getCliente());
        System.out.println("Total: S/ " + String.format("%.2f", venta.calcularTotal()));
        System.out.println("Stock martillo: " + inventario.consultarStock("P-100"));

        // ===================== AMPLIACIÓN: 15 CLASES NUEVAS =====================
        titulo("Configuración: categorías, empleado, facades y adapters");
        Categoria herramientas = new Categoria(1, "Herramientas", "Herramientas manuales y eléctricas");
        Categoria construccion = new Categoria(2, "Construcción", "Cemento, fierro y afines");
        martillo.setCategoria(herramientas);
        taladro.setCategoria(herramientas);

        Empleado vendedor = new Empleado("E-01", "Luis Ramos", "Vendedor");

        // FACADE de inventario sobre el MISMO Inventario base
        InventarioFacade inventarioFacade = new InventarioFacade(inventario);
        Producto cemento = new Producto("P-300", "Cemento 42.5kg", 28.50);
        inventarioFacade.registrarProducto(cemento, construccion, 30);
        System.out.println("Cemento (" + cemento.getCategoria() + "), stock: "
                + inventarioFacade.consultarDisponibilidad("P-300"));

        // ADAPTERS: la app solo conoce ProcesadorPago y CatalogoProveedor
        ProcesadorPago procesador = new PasarelaPagoLegacyAdapter(new PasarelaPagoLegacy());
        VentaFacade ventaFacade = new VentaFacade(vendedor, inventarioFacade, procesador);
        ComprasFacade comprasFacade = new ComprasFacade(
                vendedor, inventarioFacade, new ProveedorLegacyAdapter(new ProveedorLegacy()));

        titulo("Venta exitosa con entrega (VentaFacade + Adapter de pago)");
        Map<String, Integer> items = new LinkedHashMap<>();
        items.put("P-100", 2);
        items.put("P-300", 3);
        ResultadoVenta r1 = ventaFacade.procesarVenta(cliente, items, Pago.Medio.TARJETA, true, "Av. Los Andes 123, Junín");
        imprimir(r1);

        titulo("Venta rechazada por la pasarela (excede S/ 1000)");
        Map<String, Integer> grande = new LinkedHashMap<>();
        grande.put("P-200", 5);
        imprimir(ventaFacade.procesarVenta(cliente, grande, Pago.Medio.TARJETA, false));
        System.out.println("Stock de taladros (sin cambios): " + inventarioFacade.consultarDisponibilidad("P-200"));

        titulo("Venta sin stock suficiente");
        Map<String, Integer> sinStock = new LinkedHashMap<>();
        sinStock.put("P-200", 50);
        imprimir(ventaFacade.procesarVenta(cliente, sinStock, Pago.Medio.EFECTIVO, false));

        titulo("Reposición de martillos (ComprasFacade + Adapter de proveedor)");
        Proveedor proveedor = new Proveedor("PRV-01", "20123456789", "Distribuidora Andina S.A.C.", true);
        PedidoCompra pedido = comprasFacade.reponerProducto(proveedor, martillo, 20);
        System.out.println(pedido);
        System.out.println("Stock martillo tras recepción: " + inventarioFacade.consultarDisponibilidad("P-100"));

        titulo("Reposición con proveedor inactivo");
        Proveedor inactivo = new Proveedor("PRV-02", "20987654321", "Ferrosur E.I.R.L.", false);
        try {
            comprasFacade.reponerProducto(inactivo, martillo, 5);
        } catch (IllegalStateException e) {
            System.out.println("Error controlado: " + e.getMessage());
        }

        titulo("Reposición mayor al stock del proveedor");
        try {
            comprasFacade.reponerProducto(proveedor, taladro, 50);
        } catch (IllegalStateException e) {
            System.out.println("Error controlado: " + e.getMessage());
        }

        titulo("Ciclo de vida de la entrega");
        ServicioEntrega entrega = r1.getEntrega();
        entrega.despachar();
        System.out.println(entrega);
        entrega.entregar();
        System.out.println(entrega);

        titulo("Reporte de ventas (venta original + ventas por facade)");
        List<Venta> todas = new ArrayList<>();
        todas.add(venta);
        todas.addAll(ventaFacade.getVentasRegistradas());
        new ReporteVentas(todas).imprimir();
    }

    private static void titulo(String texto) {
        System.out.println("\n--- " + texto + " ---");
    }

    private static void imprimir(ResultadoVenta r) {
        System.out.println(r.isExitosa() ? "OK: " + r.getMensaje() : "FALLO: " + r.getMensaje());
        if (r.getPago() != null) System.out.println(r.getPago());
        if (r.getComprobante() != null) System.out.println(r.getComprobante());
        if (r.getEntrega() != null) System.out.println(r.getEntrega());
    }
}
