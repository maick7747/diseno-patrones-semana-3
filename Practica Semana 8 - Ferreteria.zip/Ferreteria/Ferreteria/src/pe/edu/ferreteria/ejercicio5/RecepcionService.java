package pe.edu.ferreteria.ejercicio5;

public class RecepcionService {
    public void registrarIngreso(int ordenId, String codigo, int cantidad) {
        System.out.println("Recepción de la orden #" + ordenId + ": " + cantidad + " x " + codigo);
    }
}
