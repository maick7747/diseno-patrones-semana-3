package pe.edu.ferreteria.ejercicio5;

// ---------- Versión CON Facade ----------
/** Resultado descriptivo: el cliente sabe POR QUÉ no se repuso (en vez de un boolean). */
public enum ResultadoReposicion {
    OK,
    CANTIDAD_INVALIDA,
    NO_REQUIERE_REPOSICION,
    PROVEEDOR_INACTIVO,
    PROVEEDOR_SIN_STOCK
}
