package pe.edu.ferreteria.ejercicio5;

public class ProveedorService {
    private final boolean activo;
    public ProveedorService(boolean activo) { this.activo = activo; }
    /** NUEVA validación: proveedor activo. */
    public boolean estaActivo() { return activo; }
    public int consultar(String codigo) { return "P-100".equals(codigo) ? 40 : (("P-300".equals(codigo)) ? 5 : 0); }
}
