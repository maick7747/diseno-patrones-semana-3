package pe.edu.ferreteria.ejercicio5;

import java.util.HashMap;
import java.util.Map;

// ---------- Subsistema ----------
public class StockService {
    private final Map<String, Integer> stock = new HashMap<>();
    public StockService() { stock.put("P-100", 2); stock.put("P-200", 50); stock.put("P-300", 1); }
    public boolean debeReponer(String codigo) { return stock.getOrDefault(codigo, 0) < 5; }
    public void aumentar(String codigo, int cantidad) { stock.merge(codigo, cantidad, Integer::sum); }
    public int stock(String codigo) { return stock.getOrDefault(codigo, 0); }
}
