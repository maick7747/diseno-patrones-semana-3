package pe.edu.ferreteria.ejercicio5;

// ---------- Versión SIN patrón ----------
public class ReposicionSinFacade {
    public void reponer(String codigo) {
        StockService stock = new StockService();
        ProveedorService proveedor = new ProveedorService(true);
        OrdenCompraService orden = new OrdenCompraService();
        RecepcionService recepcion = new RecepcionService();

        if (stock.debeReponer(codigo)) {
            int disponible = proveedor.consultar(codigo);
            if (disponible > 0) {
                int ordenId = orden.crear(codigo, 20);
                recepcion.registrarIngreso(ordenId, codigo, 20);
                stock.aumentar(codigo, 20);
            }
        }
    }
}
