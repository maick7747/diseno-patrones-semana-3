package pe.edu.ferreteria.ejercicio5;

public class Ejercicio5 {
    public static void main(String[] args) {
        System.out.println("== Sin Facade ==");
        new ReposicionSinFacade().reponer("P-100");

        StockService stock = new StockService();
        OrdenCompraService orden = new OrdenCompraService();
        RecepcionService recepcion = new RecepcionService();

        ReposicionFacade activo = new ReposicionFacade(stock, new ProveedorService(true), orden, recepcion);
        ReposicionFacade inactivo = new ReposicionFacade(new StockService(), new ProveedorService(false), orden, recepcion);

        System.out.println("\n== Con Facade ==");
        System.out.println("P-100 x20 (activo)   -> " + activo.reponer("P-100", 20));
        System.out.println("P-200 x20 (stock ok) -> " + activo.reponer("P-200", 20));
        System.out.println("P-300 x20 (prov. 5)  -> " + activo.reponer("P-300", 20));
        System.out.println("P-100 x20 (inactivo) -> " + inactivo.reponer("P-100", 20));
        System.out.println("P-100 x0             -> " + activo.reponer("P-100", 0));
        System.out.println("Stock P-100 final: " + stock.stock("P-100"));
    }
}
