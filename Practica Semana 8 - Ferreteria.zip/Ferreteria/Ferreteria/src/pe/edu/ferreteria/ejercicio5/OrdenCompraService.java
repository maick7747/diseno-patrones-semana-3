package pe.edu.ferreteria.ejercicio5;

public class OrdenCompraService {
    private int contador = 1;
    public int crear(String codigo, int cantidad) {
        System.out.println("Orden #" + contador + " creada: " + cantidad + " x " + codigo);
        return contador++;
    }
}
