package pe.edu.ferreteria.ejercicio5;

public class ReposicionFacade {
    private final StockService stock;
    private final ProveedorService proveedor;
    private final OrdenCompraService orden;
    private final RecepcionService recepcion;

    public ReposicionFacade(StockService stock, ProveedorService proveedor,
                            OrdenCompraService orden, RecepcionService recepcion) {
        this.stock = stock;
        this.proveedor = proveedor;
        this.orden = orden;
        this.recepcion = recepcion;
    }

    public ResultadoReposicion reponer(String codigo, int cantidad) {
        if (cantidad <= 0) return ResultadoReposicion.CANTIDAD_INVALIDA;
        if (!stock.debeReponer(codigo)) return ResultadoReposicion.NO_REQUIERE_REPOSICION;
        if (!proveedor.estaActivo()) return ResultadoReposicion.PROVEEDOR_INACTIVO;   // validación nueva
        if (proveedor.consultar(codigo) < cantidad) return ResultadoReposicion.PROVEEDOR_SIN_STOCK;

        int ordenId = orden.crear(codigo, cantidad);
        recepcion.registrarIngreso(ordenId, codigo, cantidad);
        stock.aumentar(codigo, cantidad);
        return ResultadoReposicion.OK;
    }
}
