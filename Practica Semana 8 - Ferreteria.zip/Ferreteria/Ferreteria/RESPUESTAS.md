# Patrones Estructurales: Adapter y Facade — Respuestas y guía del proyecto

## 1. Cómo abrirlo en IntelliJ IDEA
1. Descomprime `Ferreteria.zip`.
2. **File ▸ Open…** y selecciona la carpeta `Ferreteria`.
3. Clic derecho sobre la carpeta `src` ▸ **Mark Directory as ▸ Sources Root** (si IntelliJ no la detecta sola).
4. **File ▸ Project Structure ▸ Project ▸ SDK**: JDK 11 o superior (probado con JDK 21).
5. Ejecuta con clic derecho ▸ **Run** en:
   - `pe.edu.ferreteria.app.FerreteriaApp` (proyecto de laboratorio completo)
   - `pe.edu.ferreteria.ejercicio1.Ejercicio1` … `pe.edu.ferreteria.ejercicio5.Ejercicio5` (cada ejercicio tiene su propio paquete, al mismo nivel que `app`, `model`, etc., con su propio `main` y una clase por archivo)

## 2. Respuestas de los ejercicios

> Cada ejercicio vive en su propio paquete: `pe.edu.ferreteria.ejercicio1` … `pe.edu.ferreteria.ejercicio5`. Al estar separados, las clases mantienen los nombres originales del PDF (por ejemplo `VentaFacade` y `ServicioEntrega` del Ejercicio 4) sin chocar con las del proyecto de laboratorio.

### Ejercicio 1 — Pasarela de pago
| Rol | Clase |
|---|---|
| Cliente | `CajaConAdapter` |
| Target | `PagoService` |
| Adapter | `PagoLegacyAdapter` |
| Adaptee | `PagoLegacy` |

**Cambiar PagoLegacy sin modificar CajaConAdapter:** solo hay que construir la caja con otro `PagoService`. En el código se muestran dos casos: `PasarelaModernaAdapter` (otra librería con API distinta, adaptada) y `PagoEfectivo` (implementación nativa del Target).

**Por qué CajaConAdapter queda menos acoplada:** depende de una abstracción (`PagoService`) y no de una clase concreta. Ya no conoce el nombre del método legado (`cobrar`), la moneda (`"PEN"`) ni el tipo de dato de la API antigua. Si la librería cambia o se reemplaza, solo se toca el Adapter. Además, la dependencia se inyecta por constructor, lo que facilita pruebas con dobles.

### Ejercicio 2 — Catálogo de proveedor
- El `ProveedorAntiguo` ahora devuelve **cajas**; `ProveedorAntiguoAdapter` multiplica por `UNIDADES_POR_CAJA` y traduce `"P-100"` → `100`.
- `ReposicionConAdapter` solo hace `consultarStock(codigo) > 0`: no contiene conversiones de identificadores ni de unidades.
- Se prueba con dos proveedores que implementan `CatalogoProveedor`: el antiguo (adaptado) y `ProveedorNuevo` (nativo).

### Ejercicio 3 — Lector de códigos
- `LectorLegacyAdapter` convierte `byte[]` → `String`; `LectorInalambricoSimulado` ya implementa `LectorCodigo`.
- `PuntoVentaConAdapter` solo conoce `LectorCodigo`, por lo que funciona igual con un dispositivo nuevo o antiguo: el polimorfismo oculta la diferencia y la conversión de bytes queda encapsulada en el Adapter.

### Ejercicio 4 — Registrar una venta
**Complejidad que dejó de conocer `AppVentaConFacade`:**
- Qué servicios intervienen (inventario, pago, comprobante, entrega).
- El **orden** correcto: validar stock → cobrar → descontar → emitir.
- Las reglas de corte (no descontar si el pago falla; no cobrar si no hay stock).
- Cómo se construye y conecta cada servicio.

`ServicioEntrega` se agregó al subsistema y la Facade la invoca **solo si `requiereEntrega` es `true`**.

### Ejercicio 5 — Reposición de inventario
- **Proveedor activo:** `ProveedorService.estaActivo()` y la validación en `ReposicionFacade.reponer()`.
- **Errores en lugar de un boolean:** se usa el enum `ResultadoReposicion` con `OK`, `CANTIDAD_INVALIDA`, `NO_REQUIERE_REPOSICION`, `PROVEEDOR_INACTIVO` y `PROVEEDOR_SIN_STOCK`. El cliente puede reaccionar distinto a cada causa (avisar, reintentar con otro proveedor, ignorar). Alternativas válidas: excepciones propias (`ProveedorInactivoException`, …) o un objeto resultado con mensaje.
- **Por qué la fachada no reemplaza al subsistema:** Facade *simplifica* el caso de uso común, no lo *oculta ni lo bloquea*. Las clases `StockService`, `OrdenCompraService`, etc. siguen siendo públicas para casos avanzados (p. ej. crear una orden sin recepción inmediata o reportes). Si la fachada fuera la única vía, se convertiría en una "God class" y perdería flexibilidad; además, el subsistema sigue teniendo sus propias responsabilidades y se puede probar por separado.

## 3. Proyecto de laboratorio: Sistema de Ferretería

### Clases base (5) — no se reemplazaron
`Producto`, `Cliente`, `Inventario`, `Venta`, `FerreteriaApp`. Solo se **ampliaron** de forma compatible:
- `Producto`: nueva propiedad `categoria` (getter/setter).
- `Venta`: nuevas listas/propiedades `detalles` y `empleado`; `agregarProducto()` y `calcularTotal()` originales siguen funcionando (`calcularTotal` suma ambos orígenes → *transición compatible*).
- `FerreteriaApp`: el código original queda intacto al inicio y se añade la demostración.

### Las 15 clases nuevas
| N.º | Clase | Paquete | Patrón |
|---|---|---|---|
| 1 | `Categoria` | model | — |
| 2 | `Proveedor` | model | — |
| 3 | `Empleado` | model | — |
| 4 | `DetalleVenta` | model | — |
| 5 | `Pago` | model | — |
| 6 | `Comprobante` | model | — |
| 7 | `PedidoCompra` | model | — |
| 8 | `DetallePedidoCompra` | model | — |
| 9 | `ServicioEntrega` | model | — |
| 10 | `ReporteVentas` | service | — |
| 11 | `PasarelaPagoLegacyAdapter` | adapter | **Adapter** |
| 12 | `ProveedorLegacyAdapter` | adapter | **Adapter** |
| 13 | `VentaFacade` | facade | **Facade** |
| 14 | `InventarioFacade` | facade | **Facade** |
| 15 | `ComprasFacade` | facade | **Facade** |

**Tipos de soporte de los patrones** (los pide el enunciado, no cuentan como las 15): las interfaces `ProcesadorPago` y `CatalogoProveedor` (Targets) y las clases simuladas `PasarelaPagoLegacy` y `ProveedorLegacy` (Adaptees), todas en el paquete `adapter`.

### Decisiones de diseño
- **Categoria ↔ Producto:** se eligió una propiedad `Categoria` dentro de `Producto` (relación directa, simple y sin servicio extra); `InventarioFacade.registrarProducto(producto, categoria, stock)` la asigna al registrar.
- **Venta ↔ DetalleVenta:** `Venta` conserva `List<Producto>` y añade `List<DetalleVenta>`; así el código original no se rompe.
- **Comprobante solo tras pago aprobado:** el constructor recibe el `Pago` y lanza `IllegalStateException` si no está `APROBADO`.
- **Pasarela legado (Adapter 11):** traduce soles → céntimos, fija la moneda `"PEN"` e interpreta el código de respuesta (0 = OK). Simula un límite de S/ 1000 para probar el rechazo.
- **Proveedor legado (Adapter 12):** traduce `"P-100"` → `100` y cajas → unidades (10 por caja). Valida el formato del código.
- **VentaFacade (13):** orden = verificar stock → construir venta → pagar (vía Adapter) → retirar stock → emitir comprobante → programar entrega solo si corresponde. Si el pago es rechazado, **no** se toca el stock. Devuelve un `ResultadoVenta` descriptivo.
- **InventarioFacade (14):** centraliza validaciones (código no vacío, cantidad > 0, producto registrado, stock suficiente con mensaje claro).
- **ComprasFacade (15):** valida proveedor activo → consulta catálogo (Adapter) → crea `PedidoCompra` → agrega `DetallePedidoCompra` → simula recepción (ingresa stock y marca `RECIBIDO`).

### Salida esperada de `FerreteriaApp` (resumen)
- Venta con entrega aprobada: `Pago#1 TARJETA S/ 167.30 [APROBADO]` + boleta + entrega `PROGRAMADA`.
- Venta de 5 taladros: `Pago rechazado` por la pasarela legado (S/ 1249.50 > S/ 1000) y el stock no cambia.
- Reposición de 20 martillos: stock 7 → 27.
- Proveedor inactivo / proveedor sin stock: errores controlados.
- Reporte: 2 ventas, 6 productos, S/ 193.20 total, ticket promedio S/ 96.60.
