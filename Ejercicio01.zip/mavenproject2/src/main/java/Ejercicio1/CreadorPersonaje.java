/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio1;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class CreadorPersonaje {

    public Personaje obtenerPersonaje(String tipo) {
        if (tipo == null) {
            return null;
        }
        switch (tipo.toUpperCase()) {
            case "Guerrero":
                return new Guerrero();
            case "Mago":
                return new Mago();
            case "Arquero":
                return new Arquero();
            default:
                System.out.println("Clase desconocida.");
                return null;
        }
    }

    public void instanciar(String tipo) {
        Personaje personaje = obtenerPersonaje(tipo);
        if (personaje != null) {
            personaje.mostrarCaracteristicas();
        }
    }
}
