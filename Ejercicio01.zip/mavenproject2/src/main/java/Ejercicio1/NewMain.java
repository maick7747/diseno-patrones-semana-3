/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Ejercicio1;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        CreadorPersonaje creador = new CreadorPersonaje();

        System.out.println("-> Probando Guerrero:");
        creador.instanciar("Guerrero");

        System.out.println("\n-> Probando Mago:");
        creador.instanciar("Mago");

        System.out.println("\n-> Probando Arquero:");
        creador.instanciar("Arquero");

        System.out.println("\n-> Probando Clase Inexistente:");
        creador.instanciar("Asesino"); // Clase desconocida
    }

}
