/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio1;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class Guerrero implements Personaje {

    @Override
    public void mostrarCaracteristicas() {
        System.out.println("Creando Guerrero con espada y armadura pesada");
    }
}
