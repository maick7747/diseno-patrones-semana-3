/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Ejercicio1;

/**
 *
 * @author LAB-USR-HUANCAYO
 */
public class Mago implements Personaje {

    @Override
    public void mostrarCaracteristicas() {
        System.out.println("Creando Mago con báculo y túnica mágica...");
    }
}
